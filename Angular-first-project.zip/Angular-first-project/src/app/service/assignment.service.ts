import { Injectable } from '@angular/core';
import { Observable} from 'rxjs';
import { HttpClient,HttpHeaders} from '@angular/common/http';
import {Assign} from '../module/Assign';
@Injectable({
  providedIn: 'root'
})
export class AssignmentService {
  assignmentUrl = 'http://dummy.restapiexample.com/api/v1/employees';

  constructor( private http:HttpClient) {   }

  //Get Employee
  getAssign():Observable<Assign[]>{
    return this.http.get<Assign[]>(this.assignmentUrl);
   
  }

  //Delete Employee
  deleteAssign(assign:Assign):Observable<Assign>{
    const url= `${this.assignmentUrl}/${assign.id}`;
    return this.http.delete<Assign> (url);
   
  }
addEmployee(assign:Assign):Observable<Assign>{
  return this.http.post<Assign>(this.assignmentUrl, assign );
}

}
