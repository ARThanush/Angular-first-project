import { Component, OnInit  , Input, Output } from '@angular/core';
import {AssignmentService} from '../../service/assignment.service'
import {Assign} from '../../module/Assign'
import { EventEmitter } from 'events';

@Component({
  selector: 'app-assignment-emp',
  templateUrl: './assignment-emp.component.html',
  styleUrls: ['./assignment-emp.component.css']
})
export class AssignmentEmpComponent implements OnInit {
@Input() assign: Assign;
@Output() deleteAssign:EventEmitter<Assign> =  new EventEmitter();
  constructor(private assignmentService:AssignmentService) { }

  ngOnInit() {
  }
    onDelete(assign){
      this.deleteAssign.emit(assign);
    }

  

  
}
