import { Component, OnInit ,EventEmitter,Output} from '@angular/core';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  @Output() addEmployee:EventEmitter<any>= new EventEmitter();
  employee_name:String;
  employee_salary:Number;
  employee_age:Number;
  profile_image:File;

  constructor() { }

  ngOnInit(){
  }
  onSubmit(){
    const assign = {
      employee_name :this.employee_name,
      employee_salary:this.employee_salary,
      employee_age:this.employee_age,
      profile_image:this.profile_image



    }
  }

}
