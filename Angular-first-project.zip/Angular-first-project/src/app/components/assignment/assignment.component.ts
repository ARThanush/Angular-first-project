import { Component, OnInit } from '@angular/core';
import { Assign} from '../../module/Assign'
import { from } from 'rxjs';
import { AssignmentService} from '../../service/assignment.service'

@Component({
  selector: 'app-assignment',
  templateUrl: './assignment.component.html',
  styleUrls: ['./assignment.component.css']
})
export class AssignmentComponent implements OnInit {

  assignment:Assign[];

  constructor(private assignmentService:AssignmentService) { }

  ngOnInit() {
    this.assignmentService.getAssign().subscribe(assignment =>{
      this.assignment=assignment;
    });
  }
     deleteAssign(assign:Assign){
      this.assignment=this.assignment.filter(x=>x.id !== assign.id);
      this.assignmentService.deleteAssign(assign).subscribe();
    }
  
    addEmployee(assign:Assign){
      this.assignmentService.addEmployee(assign).subscribe( assign=>{
        this.assignment.push(assign);
      });
    }

}
