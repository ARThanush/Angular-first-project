import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { AssignmentComponent } from './components/assignment/assignment.component';
import { AssignmentEmpComponent } from './components/assignment-emp/assignment-emp.component';
import { AddEmployeeComponent } from './components/add-employee/add-employee.component';


@NgModule({
  declarations: [
    AppComponent,
    AssignmentComponent,
    AssignmentEmpComponent,
    AddEmployeeComponent,
    
  ],
  imports: [
    BrowserModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
