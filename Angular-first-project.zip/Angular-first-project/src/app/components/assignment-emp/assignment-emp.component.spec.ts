import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignmentEmpComponent } from './assignment-emp.component';

describe('AssignmentEmpComponent', () => {
  let component: AssignmentEmpComponent;
  let fixture: ComponentFixture<AssignmentEmpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignmentEmpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignmentEmpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
